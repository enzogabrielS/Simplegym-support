# SimpleGym

Web app estático responsivo, com prioridade para smartphones e adaptação para tablets e desktops. O projeto usa HTML, CSS e JavaScript sem etapa de compilação, facilitando manutenção em Chrome, Firefox e Edge.

## Estrutura

```text
simplegym/
├── index.html             # Estrutura e telas do app
├── assets/
│   ├── css/app.css        # Estilos formatados e responsivos
│   └── js/app.js          # Regras, armazenamento e interações
└── data/
    ├── exercises.json     # Catálogo de exercícios editável
    └── muscle-groups.json # Grupos musculares reutilizáveis
```

## Catálogo de exercícios

Inclua ou altere exercícios em `data/exercises.json`. Cada registro precisa ter `id`, `name`, `photo`, `description`, `muscleGroups`, `muscles` e `howTo`. Os IDs em `muscleGroups` apontam para `data/muscle-groups.json`, que contém categorias como Peito, Costas, Bíceps, Pernas, Posteriores de perna e Ombros. Em servidor HTTP/HTTPS, o JavaScript carrega e valida ambos os catálogos antes de exibi-los.

Ao abrir `index.html` diretamente pelo navegador, alguns navegadores bloqueiam a leitura de JSON local por segurança. Nesse caso, o app mantém uma prévia funcional com um catálogo de reserva. Para usar o JSON como fonte carregada, publique o app ou abra-o com qualquer servidor estático local.

## Funcionalidades

- Criar, visualizar, editar, excluir e salvar treinos.
- Associar um ou mais treinos a qualquer dia da semana.
- Iniciar, pausar e retomar uma sessão.
- Ajustar séries, repetições e carga por exercício.
- Ver foto de execução, músculos trabalhados e instruções.
- Salvar preferências e treinos no navegador com `localStorage`.

## Rastreabilidade dos requisitos

- **RF04–RF07 e RF10:** biblioteca para criar, visualizar, editar, excluir e salvar treinos.
- **RF05:** agenda semanal que define, por dia, os treinos exibidos na tela inicial.
- **RF06:** controles de séries, repetições e carga dentro do detalhe de cada exercício.
- **RF08–RF09:** início, pausa e retomada de uma sessão de treino.
- **RF11–RF12:** foto de execução, músculos envolvidos e instruções de cada exercício.
- **RNF01–RNF05:** interface mobile-first responsiva, recursos remotos, arquivos separados para manutenção e compatibilidade com Chrome, Firefox e Edge.
