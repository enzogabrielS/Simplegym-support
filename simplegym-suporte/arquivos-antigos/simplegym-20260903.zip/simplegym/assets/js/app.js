const STORAGE_KEY = 'simplegym-data-v2';
const PAUSED_SESSION_KEY = 'simplegym-paused-session-v2';
const XP_PER_WORKOUT = 60;
const scriptSource = document.currentScript?.src || new URL('assets/js/app.js', document.baseURI).href;
const EXERCISE_CATALOG_URL = new URL('../../data/exercises.json', scriptSource).href;
const MUSCLE_GROUPS_CATALOG_URL = new URL('../../data/muscle-groups.json', scriptSource).href;
const LEVELS_CATALOG_URL = new URL('../../data/levels.json', scriptSource).href;

const WEEK_DAYS = [
  { key: 'domingo', label: 'Dom', short: 'D' },
  { key: 'segunda', label: 'Seg', short: 'S' },
  { key: 'terca', label: 'Ter', short: 'T' },
  { key: 'quarta', label: 'Qua', short: 'Q' },
  { key: 'quinta', label: 'Qui', short: 'Q' },
  { key: 'sexta', label: 'Sex', short: 'S' },
  { key: 'sabado', label: 'Sáb', short: 'S' }
];

const FALLBACK_EXERCISES = [
  { id: 'puxada-alta', name: 'Puxada alta', photo: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=900&q=80', description: 'Puxe a barra em direção ao peito, mantendo o tronco firme.', muscles: ['Dorsal', 'Bíceps'], howTo: 'Segure a barra com as mãos além da largura dos ombros e solte de forma controlada.' },
  { id: 'supino-reto', name: 'Supino reto', photo: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=900&q=80', description: 'Empurre a carga para cima partindo da linha do peito.', muscles: ['Peitoral', 'Tríceps'], howTo: 'Mantenha os pés firmes no chão e desça a carga de forma controlada.' },
  { id: 'remada-baixa', name: 'Remada baixa', photo: 'https://images.unsplash.com/photo-1581009137042-c552e485697a?auto=format&fit=crop&w=900&q=80', description: 'Puxe o triângulo em direção ao abdômen e aproxime as escápulas.', muscles: ['Dorsal', 'Bíceps'], howTo: 'Evite balançar o tronco e faça o retorno lentamente.' },
  { id: 'desenvolvimento', name: 'Desenvolvimento com halteres', photo: 'https://images.unsplash.com/photo-1517963879433-6ad2b056d712?auto=format&fit=crop&w=900&q=80', description: 'Eleve os halteres acima da cabeça respeitando a linha dos ombros.', muscles: ['Ombros', 'Tríceps'], howTo: 'Mantenha o abdômen contraído e controle a descida.' },
  { id: 'agachamento', name: 'Agachamento livre', photo: 'https://images.unsplash.com/photo-1538805060514-97d9cc17730c?auto=format&fit=crop&w=900&q=80', description: 'Desça o quadril mantendo os joelhos na direção dos pés.', muscles: ['Quadríceps', 'Glúteos'], howTo: 'Mantenha o peito aberto e suba empurrando o chão.' },
  { id: 'leg-press', name: 'Leg press 45°', photo: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=900&q=80', description: 'Empurre a plataforma sem bloquear os joelhos.', muscles: ['Quadríceps', 'Glúteos'], howTo: 'Apoie a lombar no encosto e desça com controle.' },
  { id: 'rosca-direta', name: 'Rosca direta', photo: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=900&q=80', description: 'Flexione os cotovelos sem projetar os ombros.', muscles: ['Bíceps', 'Antebraços'], howTo: 'Mantenha os cotovelos próximos ao corpo e evite balanço.' },
  { id: 'prancha', name: 'Prancha abdominal', photo: 'https://images.unsplash.com/photo-1601422407692-ec4eeec1d9b3?auto=format&fit=crop&w=900&q=80', description: 'Sustente o corpo alinhado sobre antebraços e pés.', muscles: ['Core', 'Abdômen'], howTo: 'Contraia o abdômen e evite elevar ou deixar cair o quadril.' },
  { id: 'esteira', name: 'Caminhada ou corrida na esteira', type: 'cardio', photo: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=900&q=80', description: 'Caminhe ou corra em ritmo progressivo para trabalhar o condicionamento cardiovascular.', muscles: ['Sistema cardiovascular', 'Pernas'], howTo: 'Comece leve, mantenha a postura ereta e aumente o ritmo gradualmente.', muscleGroups: ['cardio', 'pernas'] },
  { id: 'bicicleta', name: 'Bicicleta ergométrica', type: 'cardio', photo: 'https://images.unsplash.com/photo-1554284126-aa88f22d8b74?auto=format&fit=crop&w=900&q=80', description: 'Pedale em intensidade controlada para desenvolver resistência cardiovascular.', muscles: ['Sistema cardiovascular', 'Quadríceps'], howTo: 'Ajuste o banco, mantenha os joelhos alinhados e escolha uma resistência confortável.', muscleGroups: ['cardio', 'pernas'] },
  { id: 'corda', name: 'Pular corda', type: 'cardio', photo: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=900&q=80', description: 'Salte de forma leve e contínua para elevar a frequência cardíaca.', muscles: ['Sistema cardiovascular', 'Panturrilhas'], howTo: 'Use giros curtos com os punhos, mantenha o abdômen firme e pouse suavemente.', muscleGroups: ['cardio', 'pernas'] }
];

const FALLBACK_MUSCLE_GROUPS = [
  { id: 'peito', name: 'Peito' },
  { id: 'costas', name: 'Costas' },
  { id: 'biceps', name: 'Bíceps' },
  { id: 'triceps', name: 'Tríceps' },
  { id: 'ombros', name: 'Ombros' },
  { id: 'pernas', name: 'Pernas' },
  { id: 'posteriores', name: 'Posteriores de perna' },
  { id: 'gluteos', name: 'Glúteos' },
  { id: 'core', name: 'Core e abdômen' },
  { id: 'antebracos', name: 'Antebraços' },
  { id: 'cardio', name: 'Cardio e condicionamento' }
];

const FALLBACK_GROUPS_BY_EXERCISE = {
  'puxada-alta': ['costas', 'biceps'],
  'supino-reto': ['peito', 'triceps', 'ombros'],
  'remada-baixa': ['costas', 'biceps'],
  desenvolvimento: ['ombros', 'triceps'],
  agachamento: ['pernas', 'posteriores', 'gluteos'],
  'leg-press': ['pernas', 'gluteos'],
  'rosca-direta': ['biceps', 'antebracos'],
  prancha: ['core'],
  esteira: ['cardio', 'pernas'],
  bicicleta: ['cardio', 'pernas'],
  corda: ['cardio', 'pernas']
};

const FALLBACK_LEVELS = [
  { level: 1, minXp: 0, title: 'Primeiro passo', description: 'Comece no seu ritmo e transforme cada treino em hábito.' },
  { level: 2, minXp: 120, title: 'Em movimento', description: 'Você já iniciou uma rotina. Continue registrando seus treinos.' },
  { level: 3, minXp: 300, title: 'Ritmo constante', description: 'A constância está aparecendo nos seus resultados.' },
  { level: 4, minXp: 550, title: 'Foco total', description: 'Seu comprometimento está cada vez mais forte.' },
  { level: 5, minXp: 900, title: 'Evolução visível', description: 'Você conquistou uma base sólida para novos desafios.' },
  { level: 6, minXp: 1400, title: 'Alta consistência', description: 'Treinar já faz parte da sua semana.' },
  { level: 7, minXp: 2100, title: 'Referência de rotina', description: 'Você atingiu o nível máximo atual do SimpleGym.' }
];

const DEFAULT_PLANS = [
  { id: 'treino-a', name: 'Superiores e core', groups: ['Costas', 'Peito', 'Core'], exercises: [
    { exerciseId: 'puxada-alta', sets: 3, reps: 12, weight: 25 },
    { exerciseId: 'supino-reto', sets: 3, reps: 10, weight: 20 },
    { exerciseId: 'remada-baixa', sets: 3, reps: 12, weight: 20 },
    { exerciseId: 'desenvolvimento', sets: 3, reps: 10, weight: 10 },
    { exerciseId: 'prancha', sets: 3, reps: 30, weight: 0 }
  ] },
  { id: 'treino-b', name: 'Inferiores', groups: ['Quadríceps', 'Glúteos'], exercises: [
    { exerciseId: 'agachamento', sets: 3, reps: 12, weight: 20 },
    { exerciseId: 'leg-press', sets: 3, reps: 12, weight: 60 },
    { exerciseId: 'prancha', sets: 3, reps: 30, weight: 0 }
  ] },
  { id: 'treino-c', name: 'Braços e ombros', groups: ['Bíceps', 'Ombros'], exercises: [
    { exerciseId: 'rosca-direta', sets: 3, reps: 12, weight: 10 },
    { exerciseId: 'desenvolvimento', sets: 3, reps: 10, weight: 8 },
    { exerciseId: 'prancha', sets: 3, reps: 30, weight: 0 }
  ] }
];

const DEFAULT_SCHEDULE = {
  domingo: [], segunda: ['treino-b'], terca: ['treino-a'], quarta: [], quinta: ['treino-c'], sexta: ['treino-a'], sabado: ['treino-b']
};

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function safeJSON(value) { try { return JSON.parse(value); } catch { return null; } }
function escapeHTML(value = '') { return String(value).replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[character])); }
function titleCase(value) { return value ? `${value.charAt(0).toUpperCase()}${value.slice(1)}` : ''; }
function deviceDate() { return new Date(); }
function todayKey() { return WEEK_DAYS[deviceDate().getDay()].key; }
function todayDateKey() {
  return localDateKey(deviceDate());
}
function localDateKey(date) {
  const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return localDate.toISOString().slice(0, 10);
}
function dateKeyOffset(offset) {
  const date = deviceDate();
  date.setDate(date.getDate() + offset);
  return localDateKey(date);
}
function getDay(key) { return WEEK_DAYS.find(day => day.key === key); }

const persisted = safeJSON(localStorage.getItem(STORAGE_KEY)) || {};
const storedCustomExercises = Array.isArray(persisted.customExercises)
  ? persisted.customExercises.filter(isValidExercise)
  : [];
const state = {
  exercises: [...clone(FALLBACK_EXERCISES), ...clone(storedCustomExercises)],
  muscleGroups: clone(FALLBACK_MUSCLE_GROUPS),
  levels: clone(FALLBACK_LEVELS),
  customExercises: clone(storedCustomExercises),
  planDraft: null,
  customExerciseReturn: 'plan',
  plans: Array.isArray(persisted.plans) ? persisted.plans : clone(DEFAULT_PLANS),
  schedule: persisted.schedule || clone(DEFAULT_SCHEDULE),
  streak: Number(persisted.streak) || 4,
  xp: Number.isFinite(Number(persisted.xp)) ? Number(persisted.xp) : 280,
  totalWorkouts: Number(persisted.totalWorkouts) || 12,
  completedDates: persisted.completedDates || {},
  freeDayCheckins: persisted.freeDayCheckins && typeof persisted.freeDayCheckins === 'object' ? persisted.freeDayCheckins : {},
  activityMinutes: Number.isFinite(Number(persisted.activityMinutes)) ? Number(persisted.activityMinutes) : 420,
  theme: ['dark', 'light', 'violet'].includes(persisted.theme) ? persisted.theme : 'dark',
  selectedDay: todayKey(),
  session: safeJSON(localStorage.getItem(PAUSED_SESSION_KEY)) || null
};

const modalBackdrop = document.getElementById('modal-backdrop');
const modalContent = document.getElementById('modal-content');
const toast = document.getElementById('toast');
let toastTimer;
let lastModalTrigger = null;

function refreshIcons() { if (window.lucide) window.lucide.createIcons(); }
function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    plans: state.plans, schedule: state.schedule, streak: state.streak, xp: state.xp,
    totalWorkouts: state.totalWorkouts, completedDates: state.completedDates, freeDayCheckins: state.freeDayCheckins,
    activityMinutes: state.activityMinutes, theme: state.theme,
    customExercises: state.customExercises
  }));
}
function getPlan(id) { return state.plans.find(plan => plan.id === id); }
function getExercise(id) { return state.exercises.find(exercise => exercise.id === id) || FALLBACK_EXERCISES.find(exercise => exercise.id === id); }
function getMuscleGroup(id) { return state.muscleGroups.find(group => group.id === id) || FALLBACK_MUSCLE_GROUPS.find(group => group.id === id); }
function getExerciseGroupIds(exercise) {
  return exercise?.muscleGroups || FALLBACK_GROUPS_BY_EXERCISE[exercise?.id] || [];
}
function getExerciseGroupNames(exercise) {
  const groupIds = getExerciseGroupIds(exercise);
  return groupIds.map(getMuscleGroup).filter(Boolean).map(group => group.name);
}
function isValidExercise(exercise) {
  return Boolean(
    exercise &&
    typeof exercise.id === 'string' &&
    typeof exercise.name === 'string' &&
    typeof exercise.photo === 'string' &&
    typeof exercise.description === 'string' &&
    typeof exercise.howTo === 'string' &&
    Array.isArray(exercise.muscleGroups) &&
    Array.isArray(exercise.muscles)
  );
}
function isValidMuscleGroup(group) {
  return Boolean(group && typeof group.id === 'string' && typeof group.name === 'string');
}
function isValidLevel(level) {
  return Boolean(
    level &&
    Number.isInteger(level.level) &&
    Number.isFinite(level.minXp) &&
    typeof level.title === 'string' &&
    typeof level.description === 'string'
  );
}
function getLevelForXp(xp) {
  return [...state.levels].sort((a, b) => a.minXp - b.minXp).filter(level => level.minXp <= xp).at(-1) || state.levels[0];
}
function getNextLevel(level) {
  return [...state.levels].sort((a, b) => a.minXp - b.minXp).find(item => item.minXp > level.minXp);
}
function formatActivity(minutes) {
  const value = Math.max(0, Math.round(Number(minutes) || 0));
  const hours = Math.floor(value / 60);
  const remainingMinutes = value % 60;
  if (hours && remainingMinutes) return `${hours}h ${remainingMinutes}min`;
  if (hours) return `${hours}h`;
  return `${remainingMinutes}min`;
}
function calculateCurrentStreak() {
  if (!Object.keys(state.completedDates).length) return state.streak;
  let offset = state.completedDates[todayDateKey()] ? 0 : -1;
  let streak = 0;
  while (state.completedDates[dateKeyOffset(offset)]) {
    streak += 1;
    offset -= 1;
  }
  return streak;
}
function syncStreak() {
  if (Object.keys(state.completedDates).length) state.streak = calculateCurrentStreak();
}
function themeLabel(theme) {
  return ({ dark: 'Tema escuro', light: 'Tema claro', violet: 'Tema violeta' })[theme] || 'Tema escuro';
}
function plansForDay(dayKey) { return (state.schedule[dayKey] || []).map(getPlan).filter(Boolean); }
function exercisesForPlans(plans) {
  return plans.flatMap(plan => plan.exercises.map((config, index) => ({ planId: plan.id, planName: plan.name, index, config, exercise: getExercise(config.exerciseId) })).filter(item => item.exercise));
}
function weightText(config) { return config.weight > 0 ? `${config.weight} kg` : 'peso corporal'; }
function isCardioExercise(exerciseId) { return getExercise(exerciseId)?.type === 'cardio'; }
function repetitionUnit(exerciseId, full = false) {
  if (isCardioExercise(exerciseId)) return full ? 'minutos' : 'min';
  if (exerciseId === 'prancha') return full ? 'segundos' : 'seg';
  return full ? 'repetições' : 'rep.';
}
function configSummary(config) {
  const weight = isCardioExercise(config.exerciseId) ? '' : ` · ${weightText(config)}`;
  return `${config.sets} séries · ${config.reps} ${repetitionUnit(config.exerciseId)}${weight}`;
}
function defaultExerciseConfig(exerciseId) {
  if (isCardioExercise(exerciseId)) return { exerciseId, sets: 1, reps: 20, weight: 0 };
  if (exerciseId === 'prancha') return { exerciseId, sets: 3, reps: 30, weight: 0 };
  return { exerciseId, sets: 3, reps: 12, weight: 10 };
}
function isCustomExercise(exerciseId) { return state.customExercises.some(exercise => exercise.id === exerciseId); }
function planLetter(index) { return String.fromCharCode(65 + (index % 26)); }

function showToast(message) {
  toast.querySelector('span').textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}
function openModal(markup, options = {}) {
  const modal = document.getElementById('modal');
  const wasOpen = modalBackdrop.classList.contains('open');
  const previousScroll = modal.scrollTop;
  if (!wasOpen) {
    const activeElement = document.activeElement;
    lastModalTrigger = activeElement instanceof HTMLElement ? activeElement : null;
  }
  modalContent.innerHTML = markup;
  modalBackdrop.classList.add('open');
  modalBackdrop.setAttribute('aria-hidden', 'false');
  modal.scrollTop = options.preserveScroll ? previousScroll : 0;
  refreshIcons();
  if (!wasOpen) requestAnimationFrame(() => modalBackdrop.querySelector('.modal-close')?.focus());
}
function closeModal() {
  // Mova o foco para fora do modal antes de escondê-lo dos leitores de tela.
  if (lastModalTrigger && document.contains(lastModalTrigger)) lastModalTrigger.focus();
  modalBackdrop.classList.remove('open');
  modalBackdrop.setAttribute('aria-hidden', 'true');
  lastModalTrigger = null;
}

function renderHome() {
  const selected = state.selectedDay;
  const today = todayKey();
  const selectedPlans = plansForDay(selected);
  const entries = exercisesForPlans(selectedPlans);
  document.getElementById('date-label').textContent = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date()).toUpperCase();
  document.getElementById('streak-number').textContent = state.streak;
  document.getElementById('xp-number').textContent = state.xp;
  document.getElementById('week-days').innerHTML = WEEK_DAYS.map(day => {
    const active = day.key === selected ? 'selected' : '';
    const scheduled = (state.schedule[day.key] || []).length ? 'scheduled' : '';
    return `<button class="week-day ${active} ${scheduled}" data-action="select-day" data-day="${day.key}" aria-label="Ver treino de ${day.label}"><span>${day.short}</span><strong>${day.label.slice(-1) === 'm' ? 'D' : day.label.slice(0, 1)}</strong><i></i></button>`;
  }).join('');
  const dayLabel = titleCase(getDay(selected).label);
  document.getElementById('day-context').textContent = selectedPlans.length ? `${dayLabel}: ${selectedPlans.map(plan => plan.name).join(' + ')}` : `${dayLabel}: dia livre`;
  document.getElementById('today-list').innerHTML = entries.slice(0, 4).map(item => `
    <article class="exercise-card">
      <div class="exercise-thumb"><img src="${escapeHTML(item.exercise.photo)}" alt="Exemplo de ${escapeHTML(item.exercise.name)}" /></div>
      <div><h3>${escapeHTML(item.exercise.name)}</h3><p>${escapeHTML(item.planName)}</p><small><i data-lucide="layers-3"></i>${configSummary(item.config)}</small></div>
      <button class="exercise-info" data-action="open-exercise" data-plan-id="${item.planId}" data-index="${item.index}" aria-label="Ver detalhes de ${escapeHTML(item.exercise.name)}"><i data-lucide="info"></i></button>
    </article>`).join('');
  const emptyWorkout = document.getElementById('empty-workout');
  const isFreeDay = entries.length === 0;
  const canCheckIn = selected === today;
  const checkedIn = Boolean(state.freeDayCheckins[todayDateKey()]) && canCheckIn;
  emptyWorkout.hidden = !isFreeDay;
  if (isFreeDay) {
    emptyWorkout.innerHTML = canCheckIn
      ? `<i data-lucide="${checkedIn ? 'circle-check-big' : 'calendar-heart'}"></i><strong>${checkedIn ? 'Check-in de dia livre realizado' : 'Hoje é um dia livre'}</strong><p>${checkedIn ? 'Sua pausa foi registrada. Volte quando estiver pronto para o próximo treino.' : 'Que tal um cardio hoje? Uma caminhada leve também conta como movimento.'}</p>`
      : '<i data-lucide="calendar-plus"></i><strong>Nenhum treino para este dia</strong><p>Organize os grupos musculares na sua agenda semanal.</p><button class="outline-button" data-action="open-schedule">Organizar agenda</button>';
  }
  const startButton = document.getElementById('home-start');
  const pausedSession = state.session && state.session.paused;
  const finishedToday = Boolean(state.completedDates[todayDateKey()]) && selected === today;
  const isCurrentDay = selected === today;
  const canCheckInToday = isFreeDay && isCurrentDay && !checkedIn;
  startButton.disabled = (!entries.length && !canCheckInToday) || finishedToday || !isCurrentDay;
  startButton.classList.toggle('paused', pausedSession);
  if (!isCurrentDay) startButton.innerHTML = '<i data-lucide="x"></i> Disponível apenas no dia';
  else if (isFreeDay && checkedIn) startButton.innerHTML = '<i data-lucide="check"></i> Check-in realizado';
  else if (isFreeDay) startButton.innerHTML = '<i data-lucide="calendar-check-2"></i> Fazer check-in de dia livre';
  else if (pausedSession) startButton.innerHTML = '<i data-lucide="play"></i> Retomar treino';
  else if (finishedToday) startButton.innerHTML = '<i data-lucide="check"></i> Treino concluído';
  else startButton.innerHTML = '<i data-lucide="play"></i> Iniciar treino';
  refreshIcons();
}

function renderProfile() {
  const level = getLevelForXp(state.xp);
  const nextLevel = getNextLevel(level);
  const progress = nextLevel
    ? Math.min(100, Math.max(0, ((state.xp - level.minXp) / (nextLevel.minXp - level.minXp)) * 100))
    : 100;

  document.getElementById('profile-level').textContent = `Nível ${level.level} · ${level.title}`;
  document.getElementById('profile-level-description').textContent = level.description;
  document.getElementById('profile-level-progress').style.width = `${progress}%`;
  document.getElementById('profile-xp').textContent = state.xp;
  document.getElementById('profile-next-xp').textContent = nextLevel ? nextLevel.minXp : state.xp;
  document.getElementById('profile-xp-copy').textContent = nextLevel
    ? `XP para o nível ${nextLevel.level}`
    : 'nível máximo alcançado';
  document.getElementById('profile-streak').textContent = state.streak;
  document.getElementById('profile-workouts').textContent = state.totalWorkouts;
  document.getElementById('profile-activity').textContent = formatActivity(state.activityMinutes);
  document.getElementById('appearance-current').textContent = themeLabel(state.theme);
}

function renderPlans() {
  document.getElementById('plans-count').textContent = `${state.plans.length} ${state.plans.length === 1 ? 'treino salvo' : 'treinos salvos'}`;
  document.getElementById('saved-plans').innerHTML = state.plans.map((plan, index) => `
    <button class="plan-card" data-action="view-plan" data-plan-id="${plan.id}">
      <span class="plan-letter">${planLetter(index)}</span>
      <span><p>${escapeHTML(plan.groups.join(' · ').toUpperCase())}</p><h3>${escapeHTML(plan.name)}</h3><small>${plan.exercises.length} exercícios · editável</small></span>
      <i data-lucide="chevron-right"></i>
    </button>`).join('');
  const savedExerciseEntries = state.plans.flatMap(plan => plan.exercises.map((config, index) => ({ plan, config, index, exercise: getExercise(config.exerciseId) })).filter(item => item.exercise));
  const usedExerciseIds = new Set(savedExerciseEntries.map(item => item.exercise.id));
  state.customExercises.filter(exercise => !usedExerciseIds.has(exercise.id)).forEach(exercise => savedExerciseEntries.push({ plan: null, config: null, index: -1, exercise }));
  const exerciseLibrary = state.muscleGroups.map(group => {
    const entries = savedExerciseEntries.filter(item => getExerciseGroupIds(item.exercise).includes(group.id));
    if (!entries.length) return '';
    return `<section class="exercise-group library-group"><div class="exercise-group-heading"><strong>${escapeHTML(group.name)}</strong><span>${entries.length} ${entries.length === 1 ? 'exercício' : 'exercícios'}</span></div><div class="saved-exercises">${entries.map(item => `
      <button class="saved-exercise-card" data-action="edit-saved-exercise" data-plan-id="${item.plan?.id || ''}" data-index="${item.index}" data-exercise-id="${item.exercise.id}">
        <img src="${escapeHTML(item.exercise.photo)}" alt="" />
        <span><p>${item.plan ? escapeHTML(item.plan.name.toUpperCase()) : 'BIBLIOTECA PESSOAL'}</p><strong>${escapeHTML(item.exercise.name)}${isCustomExercise(item.exercise.id) ? '<em class="custom-exercise-indicator">Seu</em>' : ''}</strong><small>${item.config ? configSummary(item.config) : 'Exercício criado por você'}</small></span>
        <i data-lucide="pencil"></i>
      </button>`).join('')}</div></section>`;
  }).join('');
  document.getElementById('saved-exercises').innerHTML = exerciseLibrary || '<p class="simple-copy">Crie um treino ou um exercício personalizado para montar sua biblioteca.</p>';
  document.getElementById('schedule-list').innerHTML = WEEK_DAYS.map(day => {
    const plans = plansForDay(day.key);
    const description = plans.length ? plans.map(plan => plan.name).join(' + ') : 'Sem treino programado';
    return `<button class="schedule-day ${day.key === todayKey() ? 'current' : ''}" data-action="edit-day" data-day="${day.key}"><span class="day-name">${day.label}</span><span><strong>${escapeHTML(description)}</strong><small>${plans.length ? `${plans.length} ${plans.length === 1 ? 'grupo de treino' : 'grupos de treino'}` : 'Toque para organizar'}</small></span><i data-lucide="chevron-right"></i></button>`;
  }).join('');
  refreshIcons();
}
function renderAll() { renderHome(); renderPlans(); renderProfile(); }

function navigate(page) {
  document.querySelectorAll('.page').forEach(section => section.classList.toggle('active', section.dataset.page === page));
  document.querySelectorAll('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.nav === page));
  document.querySelector(`.page[data-page="${page}"]`).scrollTop = 0;
}
function selectTab(name) {
  document.querySelectorAll('[data-tab]').forEach(button => button.classList.toggle('selected', button.dataset.tab === name));
  document.querySelectorAll('[data-panel]').forEach(panel => panel.classList.toggle('active', panel.dataset.panel === name));
}

function openPlanView(planId) {
  const plan = getPlan(planId);
  if (!plan) return;
  const index = state.plans.indexOf(plan);
  openModal(`
    <div class="modal-plan-header"><span class="modal-letter">${planLetter(index)}</span><div><h2 class="modal-title" id="modal-title">${escapeHTML(plan.name)}</h2><p class="modal-subtitle">${escapeHTML(plan.groups.join(' · '))}</p></div></div>
    <button class="modal-top-action" data-action="open-plan-form" data-plan-id="${plan.id}">Editar</button>
    <div class="modal-exercises">${plan.exercises.map((config, itemIndex) => {
      const exercise = getExercise(config.exerciseId);
      return `<button class="modal-exercise" data-action="open-exercise" data-plan-id="${plan.id}" data-index="${itemIndex}"><span>${String(itemIndex + 1).padStart(2, '0')}</span><span><strong>${escapeHTML(exercise?.name || 'Exercício')}</strong><small>${configSummary(config)}</small></span><i data-lucide="sliders-horizontal"></i></button>`;
    }).join('')}</div>
    <div class="modal-button-row"><button class="modal-cta secondary" data-action="open-plan-form" data-plan-id="${plan.id}">Editar treino</button><button class="modal-cta" data-action="start-plan" data-plan-id="${plan.id}">Começar</button></div>
    <button class="danger-button" data-action="confirm-delete-plan" data-plan-id="${plan.id}">Excluir treino</button>`);
}

function openSavedExerciseEditor(planId, index, exerciseId = '') {
  const plan = planId ? getPlan(planId) : null;
  const config = plan?.exercises[Number(index)] || null;
  const exercise = config ? getExercise(config.exerciseId) : getExercise(exerciseId);
  if (!exercise) return;
  const custom = isCustomExercise(exercise.id);
  const groupOptions = custom ? `<div class="custom-group-picker">${state.muscleGroups.map(group => `<label><input type="checkbox" data-edit-custom-group value="${group.id}" ${getExerciseGroupIds(exercise).includes(group.id) ? 'checked' : ''} /><span>${escapeHTML(group.name)}</span></label>`).join('')}</div>` : `<div class="muscle-pills">${getExerciseGroupNames(exercise).map(group => `<span>${escapeHTML(group)}</span>`).join('')}</div>`;
  openModal(`
    <h2 class="modal-title" id="modal-title">${custom ? 'Editar exercício' : escapeHTML(exercise.name)}</h2>
    <p class="modal-subtitle">${plan ? `${escapeHTML(plan.name)} · ` : ''}${custom ? 'dados e carga podem ser atualizados' : 'ajuste a carga deste treino'}</p>
    <div class="exercise-detail-photo"><img src="${escapeHTML(exercise.photo)}" alt="Exemplo de ${escapeHTML(exercise.name)}" /></div>
    <div class="form-group"><label for="saved-exercise-weight">Carga (kg)</label>${!config ? '<p class="form-hint">Adicione este exercício a um treino para definir uma carga.</p>' : isCardioExercise(exercise.id) ? '<p class="form-hint">Exercícios de cardio não utilizam carga.</p>' : `<input id="saved-exercise-weight" type="number" min="0" step="1" value="${Number(config.weight) || 0}" />`}</div>
    ${custom ? `
      <div class="form-group"><label for="edit-custom-name">Nome</label><input id="edit-custom-name" value="${escapeHTML(exercise.name)}" maxlength="55" /></div>
      <div class="form-group"><label for="edit-custom-photo-url">Link da foto</label><input id="edit-custom-photo-url" type="url" inputmode="url" value="${exercise.photo.startsWith('data:') ? '' : escapeHTML(exercise.photo)}" placeholder="Mantenha em branco para usar a foto atual" /></div>
      <div class="form-group"><label for="edit-custom-photo-file">Nova foto do dispositivo</label><input id="edit-custom-photo-file" class="file-input" type="file" accept="image/*" /></div>
      <div class="form-group"><label for="edit-custom-muscles">Músculos em foco</label><input id="edit-custom-muscles" value="${escapeHTML(exercise.muscles.join(', '))}" maxlength="100" /></div>
      <div class="form-group"><label for="edit-custom-description">Descrição</label><textarea id="edit-custom-description" maxlength="300">${escapeHTML(exercise.description)}</textarea></div>
      <div class="form-group"><label for="edit-custom-how-to">Como executar</label><textarea id="edit-custom-how-to" maxlength="400">${escapeHTML(exercise.howTo)}</textarea></div>
      <div class="form-group"><label>Grupos musculares</label>${groupOptions}</div>
    ` : `<div class="detail-copy"><strong>Grupos musculares</strong>${groupOptions}</div><div class="detail-copy"><strong>Descrição</strong><p>${escapeHTML(exercise.description)}</p></div><p class="form-hint">Nome, foto, descrição e grupos pertencem ao catálogo padrão e não podem ser alterados.</p>`}
    <button class="modal-cta" style="margin-top:20px" data-action="save-saved-exercise" data-plan-id="${plan?.id || ''}" data-index="${index}" data-exercise-id="${exercise.id}">Salvar alterações</button>`);
}

async function saveSavedExerciseEditor(planId, index, exerciseId = '') {
  const plan = planId ? getPlan(planId) : null;
  const config = plan?.exercises[Number(index)] || null;
  const exercise = config ? getExercise(config.exerciseId) : getExercise(exerciseId);
  if (!exercise) return;
  const weightInput = document.getElementById('saved-exercise-weight');
  if (weightInput) {
    const weight = Number(weightInput.value);
    if (!Number.isFinite(weight) || weight < 0) { showToast('Informe uma carga igual ou maior que zero.'); return; }
    if (config) config.weight = weight;
  }
  if (isCustomExercise(exercise.id)) {
    const name = document.getElementById('edit-custom-name').value.trim();
    const photoUrl = document.getElementById('edit-custom-photo-url').value.trim();
    const photoFile = document.getElementById('edit-custom-photo-file').files[0];
    const muscles = document.getElementById('edit-custom-muscles').value.split(',').map(muscle => muscle.trim()).filter(Boolean);
    const description = document.getElementById('edit-custom-description').value.trim();
    const howTo = document.getElementById('edit-custom-how-to').value.trim();
    const muscleGroups = [...document.querySelectorAll('[data-edit-custom-group]:checked')].map(input => input.value);
    if (!name || !muscles.length || !description || !howTo || !muscleGroups.length) { showToast('Preencha os dados do exercício personalizado.'); return; }
    let photo = exercise.photo;
    try {
      if (photoFile) photo = await readDeviceImage(photoFile);
      else if (photoUrl) {
        if (!/^https?:\/\//i.test(photoUrl)) throw new Error('Use um link de imagem válido.');
        photo = photoUrl;
      }
    } catch (error) { showToast(error.message); return; }
    const updatedExercise = { ...exercise, name, photo, muscles, description, howTo, muscleGroups };
    state.customExercises = state.customExercises.map(item => item.id === exercise.id ? updatedExercise : item);
    state.exercises = state.exercises.map(item => item.id === exercise.id ? updatedExercise : item);
  }
  try { saveState(); } catch { showToast('Não foi possível salvar a imagem. Tente uma foto menor.'); return; }
  renderAll();
  closeModal();
  navigate('workouts');
  selectTab('exercises');
  showToast('Exercício atualizado.');
}

function openPlanForm(planId = '', draft = null) {
  const plan = planId ? getPlan(planId) : null;
  const activeDraft = draft || state.planDraft;
  const selectedIds = activeDraft?.selectedIds || plan?.exercises.map(config => config.exerciseId) || [];
  const selectedOrder = new Map(selectedIds.map((id, index) => [id, index + 1]));
  const exerciseSections = state.muscleGroups.map(group => {
    const exercises = state.exercises.filter(exercise => getExerciseGroupIds(exercise).includes(group.id));
    if (!exercises.length) return '';
    return `<section class="exercise-group"><div class="exercise-group-heading"><strong>${escapeHTML(group.name)}</strong><span>${exercises.length} ${exercises.length === 1 ? 'exercício' : 'exercícios'}</span></div><div class="exercise-picker">${exercises.map(exercise => { const order = selectedOrder.get(exercise.id); return `<button class="exercise-choice ${order ? 'selected' : ''}" data-action="toggle-plan-exercise" data-exercise-id="${exercise.id}" data-order="${order || ''}" aria-pressed="${Boolean(order)}"><i>${order ? String(order).padStart(2, '0') : ''}</i><span>${escapeHTML(exercise.name)}</span></button>`; }).join('')}</div></section>`;
  }).join('');
  openModal(`
    <h2 class="modal-title" id="modal-title">${plan ? 'Editar treino' : 'Novo treino'}</h2>
    <p class="modal-subtitle">${plan ? 'Atualize a estrutura do seu treino salvo.' : 'Escolha os exercícios e salve para usar quando quiser.'}</p>
    <div class="form-group"><label for="plan-name">Nome do treino</label><input id="plan-name" value="${escapeHTML(activeDraft?.name ?? plan?.name ?? '')}" placeholder="Ex.: Peito e tríceps" maxlength="40" /></div>
    <div class="form-group"><label for="plan-groups">Grupos musculares</label><input id="plan-groups" value="${escapeHTML(activeDraft?.groups ?? plan?.groups.join(', ') ?? '')}" placeholder="Ex.: Peito, tríceps" maxlength="65" /><p class="form-hint">Separe mais de um grupo por vírgula.</p></div>
    <div class="form-group"><div class="exercise-form-heading"><label>Exercícios</label><button class="add-exercise-button" data-action="open-custom-exercise" data-plan-id="${plan?.id || ''}" data-return="plan"><i data-lucide="plus"></i> Novo exercício</button></div><p class="form-hint">Toque nos itens na ordem em que deseja executá-los.</p><div class="exercise-groups">${exerciseSections}</div></div>
    <button class="modal-cta" style="margin-top:20px" data-action="save-plan" data-plan-id="${plan?.id || ''}">${plan ? 'Salvar alterações' : 'Salvar treino'}</button>`);
  modalContent.dataset.selectedExerciseIds = selectedIds.join(',');
  state.planDraft = null;
}

function savePlan(planId = '') {
  const name = document.getElementById('plan-name').value.trim();
  const groups = document.getElementById('plan-groups').value.split(',').map(group => group.trim()).filter(Boolean);
  const selectedIds = (modalContent.dataset.selectedExerciseIds || '').split(',').filter(Boolean);
  if (!name || !groups.length || !selectedIds.length) { showToast('Preencha o nome, os grupos e selecione exercícios.'); return; }
  const oldPlan = planId ? getPlan(planId) : null;
  const exercises = selectedIds.map(id => oldPlan?.exercises.find(config => config.exerciseId === id) || defaultExerciseConfig(id));
  const plan = { id: planId || `treino-${Date.now()}`, name, groups, exercises };
  if (oldPlan) state.plans = state.plans.map(item => item.id === planId ? plan : item);
  else state.plans.push(plan);
  state.planDraft = null;
  saveState(); renderAll(); closeModal(); navigate('workouts'); showToast(oldPlan ? 'Treino atualizado com sucesso.' : 'Novo treino salvo com sucesso.');
}
function togglePlanExercise(choice) {
  const exerciseId = choice.dataset.exerciseId;
  const selectedIds = (modalContent.dataset.selectedExerciseIds || '').split(',').filter(Boolean);
  const selectedIndex = selectedIds.indexOf(exerciseId);
  if (selectedIndex >= 0) selectedIds.splice(selectedIndex, 1);
  else selectedIds.push(exerciseId);
  modalContent.dataset.selectedExerciseIds = selectedIds.join(',');

  document.querySelectorAll('.exercise-choice').forEach(item => {
    const order = selectedIds.indexOf(item.dataset.exerciseId) + 1;
    const isSelected = order > 0;
    item.classList.toggle('selected', isSelected);
    item.dataset.order = isSelected ? order : '';
    item.setAttribute('aria-pressed', String(isSelected));
    item.querySelector('i').textContent = isSelected ? String(order).padStart(2, '0') : '';
  });
}
function capturePlanDraft(planId = '') {
  state.planDraft = {
    planId,
    name: document.getElementById('plan-name')?.value || '',
    groups: document.getElementById('plan-groups')?.value || '',
    selectedIds: (modalContent.dataset.selectedExerciseIds || '').split(',').filter(Boolean)
  };
}
function openCustomExerciseForm(planId = '', returnTo = 'plan') {
  if (returnTo === 'plan') capturePlanDraft(planId);
  else state.planDraft = null;
  state.customExerciseReturn = returnTo;
  openModal(`
    <h2 class="modal-title" id="modal-title">Novo exercício</h2>
    <p class="modal-subtitle">Ele ficará disponível apenas neste navegador, na seção dos grupos escolhidos.</p>
    <div class="form-group"><label for="custom-exercise-name">Nome</label><input id="custom-exercise-name" placeholder="Ex.: Elevação lateral" maxlength="55" /></div>
    <div class="form-group"><label for="custom-photo-url">Link da foto</label><input id="custom-photo-url" type="url" inputmode="url" placeholder="https://exemplo.com/foto.jpg" /><p class="form-hint">Use um link de imagem ou envie uma foto abaixo.</p></div>
    <div class="form-group"><label for="custom-photo-file">Foto do dispositivo</label><input id="custom-photo-file" class="file-input" type="file" accept="image/*" /></div>
    <div class="form-group"><label for="custom-muscles">Músculos em foco</label><input id="custom-muscles" placeholder="Ex.: Deltoide lateral, trapézio" maxlength="100" /></div>
    <div class="form-group"><label for="custom-description">Descrição</label><textarea id="custom-description" placeholder="Explique o objetivo do exercício." maxlength="300"></textarea></div>
    <div class="form-group"><label for="custom-how-to">Como executar</label><textarea id="custom-how-to" placeholder="Descreva a execução com segurança." maxlength="400"></textarea></div>
    <div class="form-group"><label>Grupos musculares</label><div class="custom-group-picker">${state.muscleGroups.map(group => `<label><input type="checkbox" data-custom-group value="${group.id}" /><span>${escapeHTML(group.name)}</span></label>`).join('')}</div></div>
    <button class="modal-cta" style="margin-top:20px" data-action="save-custom-exercise">Salvar exercício</button>`);
}
function readDeviceImage(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/')) { reject(new Error('Selecione uma imagem válida.')); return; }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('Não foi possível processar a imagem.'));
      image.onload = () => {
        const maxSide = 900;
        const scale = Math.min(1, maxSide / Math.max(image.width, image.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', .82));
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
async function saveCustomExercise() {
  const name = document.getElementById('custom-exercise-name').value.trim();
  const photoUrl = document.getElementById('custom-photo-url').value.trim();
  const photoFile = document.getElementById('custom-photo-file').files[0];
  const muscles = document.getElementById('custom-muscles').value.split(',').map(muscle => muscle.trim()).filter(Boolean);
  const description = document.getElementById('custom-description').value.trim();
  const howTo = document.getElementById('custom-how-to').value.trim();
  const muscleGroups = [...document.querySelectorAll('[data-custom-group]:checked')].map(input => input.value);
  if (!name || !muscles.length || !description || !howTo || !muscleGroups.length || (!photoUrl && !photoFile)) {
    showToast('Preencha todos os campos e escolha uma foto.');
    return;
  }
  let photo = photoUrl;
  try {
    if (photoFile) photo = await readDeviceImage(photoFile);
    else if (!/^https?:\/\//i.test(photo)) throw new Error('Use um link de imagem válido.');
  } catch (error) {
    showToast(error.message);
    return;
  }
  const exercise = { id: `personalizado-${Date.now()}`, name, photo, description, howTo, muscles, muscleGroups };
  state.customExercises.push(exercise);
  state.exercises.push(exercise);
  try {
    saveState();
  } catch {
    state.customExercises.pop();
    state.exercises = state.exercises.filter(item => item.id !== exercise.id);
    showToast('A imagem é grande demais para ser salva. Tente outra foto.');
    return;
  }
  const draft = state.planDraft;
  if (state.customExerciseReturn === 'library') {
    state.customExerciseReturn = 'plan';
    renderAll();
    closeModal();
    navigate('workouts');
    selectTab('exercises');
  } else openPlanForm(draft?.planId || '', draft);
  showToast('Exercício personalizado salvo.');
}

function openScheduleEditor(dayKey) {
  const day = getDay(dayKey);
  const selected = new Set(state.schedule[dayKey] || []);
  openModal(`
    <h2 class="modal-title" id="modal-title">${day.label}: grupos de treino</h2>
    <p class="modal-subtitle">Você pode escolher mais de um treino para o mesmo dia.</p>
    <div class="modal-exercises">${state.plans.length ? state.plans.map(plan => `<label class="check-row"><input type="checkbox" data-schedule-plan value="${plan.id}" ${selected.has(plan.id) ? 'checked' : ''}/><span><strong>${escapeHTML(plan.name)}</strong><small>${escapeHTML(plan.groups.join(' · '))}</small></span></label>`).join('') : '<p class="simple-copy">Crie pelo menos um treino antes de montar a agenda.</p>'}</div>
    <button class="modal-cta" data-action="save-day" data-day="${dayKey}">Salvar agenda de ${day.label}</button>`);
}
function saveDay(dayKey) {
  state.schedule[dayKey] = [...document.querySelectorAll('[data-schedule-plan]:checked')].map(input => input.value);
  state.selectedDay = dayKey;
  saveState(); renderAll(); closeModal(); showToast('Agenda semanal atualizada.');
}

function openExerciseDetail(planId, index, preserveScroll = false) {
  const plan = getPlan(planId);
  const config = plan?.exercises[Number(index)];
  const exercise = config && getExercise(config.exerciseId);
  if (!plan || !config || !exercise) return;
  openModal(`
    <h2 class="modal-title" id="modal-title">${escapeHTML(exercise.name)}</h2>
    <p class="modal-subtitle">${escapeHTML(plan.name)} · ajuste livremente antes do treino</p>
    <div class="exercise-detail-photo"><img src="${escapeHTML(exercise.photo)}" alt="Exemplo de execução de ${escapeHTML(exercise.name)}" /></div>
    <div class="detail-copy"><strong>Grupos musculares</strong><div class="muscle-pills">${getExerciseGroupNames(exercise).map(group => `<span>${escapeHTML(group)}</span>`).join('')}</div></div>
    <div class="detail-copy"><strong>Músculos em foco</strong><p>${escapeHTML(exercise.muscles.join(' · '))}</p></div>
    <div class="detail-copy"><strong>O que você treina</strong><p>${escapeHTML(exercise.description)}</p></div>
    <div class="detail-copy"><strong>Como executar</strong><p>${escapeHTML(exercise.howTo)}</p></div>
    <div class="config-grid">${[
      ['sets', 'Séries', config.sets, ''],
      ['reps', isCardioExercise(config.exerciseId) ? 'Duração' : 'Repetições', config.reps, isCardioExercise(config.exerciseId) ? ' min' : ' rep.'],
      ...(!isCardioExercise(config.exerciseId) ? [['weight', 'Carga', config.weight, ' kg']] : [])
    ].map(([field, label, value, suffix]) => {
      if (field === 'weight') return `<div class="config-card weight-config"><small>${label}</small><div class="config-control"><button data-action="change-config" data-plan-id="${plan.id}" data-index="${index}" data-field="weight" data-delta="-5" aria-label="Diminuir carga em 5 kg">−5</button><button data-action="change-config" data-plan-id="${plan.id}" data-index="${index}" data-field="weight" data-delta="-1" aria-label="Diminuir carga em 1 kg">−1</button><strong>${value}${suffix}</strong><button data-action="change-config" data-plan-id="${plan.id}" data-index="${index}" data-field="weight" data-delta="1" aria-label="Aumentar carga em 1 kg">+1</button><button data-action="change-config" data-plan-id="${plan.id}" data-index="${index}" data-field="weight" data-delta="5" aria-label="Aumentar carga em 5 kg">+5</button></div></div>`;
      return `<div class="config-card"><small>${label}</small><div class="config-control"><button data-action="change-config" data-plan-id="${plan.id}" data-index="${index}" data-field="${field}" data-delta="-1" aria-label="Diminuir ${label}"><i data-lucide="minus"></i></button><strong>${value}${suffix}</strong><button data-action="change-config" data-plan-id="${plan.id}" data-index="${index}" data-field="${field}" data-delta="1" aria-label="Aumentar ${label}"><i data-lucide="plus"></i></button></div></div>`;
    }).join('')}</div>
    <button class="modal-cta" style="margin-top:18px" data-action="close-modal">Salvar ajustes</button>`, { preserveScroll });
}
function changeConfig(planId, index, field, delta) {
  const config = getPlan(planId)?.exercises[Number(index)];
  if (!config) return;
  const min = field === 'weight' ? 0 : 1;
  config[field] = Math.max(min, Number(config[field]) + Number(delta));
  saveState(); renderAll(); openExerciseDetail(planId, index, true);
}
function checkInFreeDay() {
  if (state.selectedDay !== todayKey()) {
    showToast('O check-in de dia livre só pode ser feito no dia atual.');
    return;
  }
  const date = todayDateKey();
  if (state.freeDayCheckins[date]) return;
  state.freeDayCheckins[date] = true;
  saveState();
  renderHome();
  showToast('Pausa registrada. Cuidar da recuperação também faz parte do treino.');
}

function startWorkout(planIds, options = {}) {
  if (!options.allowRepeat && state.selectedDay !== todayKey()) {
    showToast('Os treinos só podem ser iniciados no dia atual.');
    return;
  }
  if (state.session?.paused) { resumeSession(); return; }
  const plans = planIds.map(getPlan).filter(Boolean);
  const exercises = exercisesForPlans(plans).map(item => ({ planId: item.planId, planName: item.planName, exerciseId: item.config.exerciseId, sets: item.config.sets, reps: item.config.reps, weight: item.config.weight }));
  if (!exercises.length) { showToast('Selecione exercícios antes de iniciar um treino.'); return; }
  state.session = {
    planIds,
    exercises,
    exerciseIndex: 0,
    completedSets: 0,
    paused: false,
    startedAt: Date.now(),
    activeMilliseconds: 0,
    rewardXp: options.rewardXp !== false
  };
  openSession();
}
function openSession() {
  const session = state.session;
  const item = session?.exercises[session.exerciseIndex];
  const exercise = item && getExercise(item.exerciseId);
  if (!session || !item || !exercise) return;
  const progress = session.exercises.map((_, index) => `<i class="${index <= session.exerciseIndex ? 'active' : ''}"></i>`).join('');
  const sets = Array.from({ length: item.sets }, (_, index) => `<span class="${index < session.completedSets ? 'done' : ''}">${index + 1}</span>`).join('');
  openModal(`
    <div class="session-progress">${progress}</div>
    <div class="session-photo"><img src="${escapeHTML(exercise.photo)}" alt="${escapeHTML(exercise.name)}" /><span><i data-lucide="info"></i> Exemplo de execução</span></div>
    <div class="session-info"><p class="micro-title">EXERCÍCIO ${session.exerciseIndex + 1} DE ${session.exercises.length}</p><h2 class="modal-title" id="modal-title">${escapeHTML(exercise.name)}</h2><p>${configSummary(item).replace('rep.', 'repetições').replace(' min', ' minutos').replace(' seg', ' segundos')}</p></div>
    <div class="set-indicators">${sets}</div>
    <div class="session-buttons"><button class="pause" data-action="pause-session"><i data-lucide="pause"></i> Pausar</button><button class="finish-set" data-action="complete-set">Concluir série</button></div>`);
}
function pauseSession() {
  if (!state.session) return;
  state.session.activeMilliseconds = Number(state.session.activeMilliseconds || 0) + Math.max(0, Date.now() - Number(state.session.startedAt || Date.now()));
  state.session.paused = true;
  localStorage.setItem(PAUSED_SESSION_KEY, JSON.stringify(state.session));
  closeModal(); renderHome(); showToast('Treino pausado. Você pode retomar quando quiser.');
}
function resumeSession() {
  if (!state.session) return;
  state.session.paused = false;
  state.session.startedAt = Date.now();
  localStorage.removeItem(PAUSED_SESSION_KEY);
  openSession();
}
function completeSet() {
  const session = state.session;
  if (!session) return;
  const item = session.exercises[session.exerciseIndex];
  session.completedSets += 1;
  if (session.completedSets < item.sets) { openSession(); showToast('Série registrada. Continue assim!'); return; }
  session.exerciseIndex += 1;
  session.completedSets = 0;
  if (session.exerciseIndex >= session.exercises.length) finishWorkout();
  else { openSession(); showToast('Exercício concluído! Próximo movimento.'); }
}
function finishWorkout() {
  const date = todayDateKey();
  const isFirstWorkoutToday = !state.completedDates[date];
  const activeMilliseconds = Number(state.session?.activeMilliseconds || 0) + Math.max(0, Date.now() - Number(state.session?.startedAt || Date.now()));
  const activityAdded = Math.max(1, Math.round(activeMilliseconds / 60000));
  const earnsXp = state.session?.rewardXp !== false;
  const completedPlanIds = [...(state.session?.planIds || [])];

  // Todo treino concluído concede XP, mesmo quando já houve outro treino no mesmo dia.
  if (earnsXp) state.xp += XP_PER_WORKOUT;
  state.totalWorkouts += 1;
  state.activityMinutes += activityAdded;

  if (isFirstWorkoutToday) {
    state.completedDates[date] = true;
    state.streak = calculateCurrentStreak();
  }
  state.session = null;
  localStorage.removeItem(PAUSED_SESSION_KEY);
  saveState(); renderAll();
  openModal(`<div class="celebration"><span class="celebration-badge"><i data-lucide="party-popper"></i></span><p class="micro-title">TREINO CONCLUÍDO</p><h2 class="modal-title" id="modal-title">Você conseguiu!</h2><p>Mais um passo para a sua evolução. A sequência continua acesa.</p><div class="reward-grid"><article><strong>${earnsXp ? `+${XP_PER_WORKOUT} XP` : 'Sem XP'}</strong><span>${earnsXp ? 'experiência ganha' : 'treino repetido'}</span></article><article><strong>+${activityAdded} min</strong><span>em atividade</span></article><article><strong>${state.streak} dias 🔥</strong><span>${isFirstWorkoutToday ? 'nova sequência' : 'sequência mantida'}</span></article></div><div class="modal-button-row"><button class="modal-cta secondary" data-action="repeat-workout" data-plan-ids="${completedPlanIds.join(',')}">Repetir sem XP</button><button class="modal-cta" data-action="finish-celebration">Concluir</button></div></div>`);
}

function confirmDeletePlan(planId) {
  const plan = getPlan(planId);
  if (!plan) return;
  openModal(`<div class="simple-icon"><i data-lucide="triangle-alert"></i></div><h2 class="modal-title" id="modal-title">Excluir treino?</h2><p class="simple-copy">“${escapeHTML(plan.name)}” será removido da agenda semanal e não poderá ser recuperado.</p><div class="modal-button-row"><button class="modal-cta secondary" data-action="view-plan" data-plan-id="${planId}">Cancelar</button><button class="modal-cta" style="background:#ff7d6d" data-action="delete-plan" data-plan-id="${planId}">Excluir</button></div>`);
}
function deletePlan(planId) {
  state.plans = state.plans.filter(plan => plan.id !== planId);
  WEEK_DAYS.forEach(day => { state.schedule[day.key] = (state.schedule[day.key] || []).filter(id => id !== planId); });
  saveState(); renderAll(); closeModal(); showToast('Treino excluído da sua biblioteca.');
}

function applyTheme(theme, announce = true) {
  if (!['dark', 'light', 'violet'].includes(theme)) return;
  state.theme = theme;
  document.body.dataset.theme = theme;
  saveState();
  renderProfile();
  if (announce) showToast(`${themeLabel(theme)} aplicado.`);
}
function openAppearanceModal() {
  const themes = [
    { id: 'dark', name: 'Escuro', description: 'Contraste confortável para treinar à noite.' },
    { id: 'light', name: 'Claro', description: 'Visual leve e luminoso para o dia.' },
    { id: 'violet', name: 'Violeta', description: 'Uma variação escura com toque roxo.' }
  ];
  openModal(`<div class="simple-icon"><i data-lucide="palette"></i></div><h2 class="modal-title" id="modal-title">Aparência</h2><p class="simple-copy">Escolha o tema que combina melhor com sua rotina. A preferência fica salva neste navegador.</p><div class="theme-options">${themes.map(theme => `<button class="theme-option ${state.theme === theme.id ? 'selected' : ''}" data-action="set-theme" data-theme="${theme.id}" aria-pressed="${state.theme === theme.id}"><span class="theme-preview ${theme.id}"><i></i><i></i></span><span><strong>${theme.name}</strong><small>${theme.description}</small></span><i data-lucide="${state.theme === theme.id ? 'check-circle-2' : 'circle'}"></i></button>`).join('')}</div><button class="modal-cta secondary" data-action="close-modal">Concluir</button>`);
}

function openSimpleModal(type) {
  const entries = {
    'edit-profile': ['pencil', 'Editar perfil', 'Nesta área você poderá personalizar nome, foto, objetivo e nível de experiência ao conectar a sua conta.'],
    goals: ['target', 'Meta semanal', 'Sua meta é fazer 4 treinos por semana. Você pode aumentar ou reduzir essa frequência sempre que precisar.'],
    privacy: ['shield-check', 'Privacidade e dados', 'Seus treinos salvos ficam armazenados neste navegador. Você pode controlar seus dados quando desejar.'],
    help: ['circle-help', 'Ajuda e suporte', 'Use a agenda semanal para organizar grupos musculares e toque no exercício para ver execução, músculos e ajustes.']
  };
  if (type === 'appearance') { openAppearanceModal(); return; }
  if (type === 'reminders') {
    openModal(`<div class="simple-icon"><i data-lucide="bell-ring"></i></div><h2 class="modal-title" id="modal-title">Lembretes</h2><p class="simple-copy">Defina como o SimpleGym deve ajudar você a manter a rotina.</p><div class="switch-row"><div><strong>Lembrete de treino</strong><small>Terças e quintas, às 18h</small></div><button class="switch on" data-action="toggle-switch" aria-label="Ativar lembretes"></button></div><button class="modal-cta" style="margin-top:18px" data-action="close-modal">Salvar preferência</button>`);
    return;
  }
  const [icon, title, text] = entries[type] || ['sparkles', 'SimpleGym', 'Tudo pronto para o seu próximo treino.'];
  openModal(`<div class="simple-icon"><i data-lucide="${icon}"></i></div><h2 class="modal-title" id="modal-title">${title}</h2><p class="simple-copy">${text}</p><button class="modal-cta" data-action="close-modal">Entendi</button>`);
}

document.addEventListener('click', event => {
  const target = event.target.closest('[data-action], [data-nav], [data-tab]');
  if (!target) return;
  if (target.dataset.nav) { navigate(target.dataset.nav); return; }
  if (target.dataset.tab) { selectTab(target.dataset.tab); return; }
  const action = target.dataset.action;
  if (action === 'select-day') { state.selectedDay = target.dataset.day; renderHome(); }
  else if (action === 'open-workouts') { navigate('workouts'); }
  else if (action === 'open-profile') { navigate('profile'); }
  else if (action === 'open-schedule') { navigate('workouts'); selectTab('schedule'); }
  else if (action === 'create-plan') openPlanForm();
  else if (action === 'view-plan') openPlanView(target.dataset.planId);
  else if (action === 'open-plan-form') openPlanForm(target.dataset.planId);
  else if (action === 'toggle-plan-exercise') togglePlanExercise(target);
  else if (action === 'open-custom-exercise') openCustomExerciseForm(target.dataset.planId, target.dataset.return);
  else if (action === 'save-custom-exercise') saveCustomExercise();
  else if (action === 'edit-saved-exercise') openSavedExerciseEditor(target.dataset.planId, target.dataset.index, target.dataset.exerciseId);
  else if (action === 'save-saved-exercise') saveSavedExerciseEditor(target.dataset.planId, target.dataset.index, target.dataset.exerciseId);
  else if (action === 'save-plan') savePlan(target.dataset.planId);
  else if (action === 'edit-day') openScheduleEditor(target.dataset.day);
  else if (action === 'save-day') saveDay(target.dataset.day);
  else if (action === 'open-exercise') openExerciseDetail(target.dataset.planId, target.dataset.index);
  else if (action === 'change-config') changeConfig(target.dataset.planId, target.dataset.index, target.dataset.field, target.dataset.delta);
  else if (action === 'free-day-checkin') checkInFreeDay();
  else if (action === 'start-day-workout') {
    if (!exercisesForPlans(plansForDay(state.selectedDay)).length) checkInFreeDay();
    else startWorkout(state.schedule[state.selectedDay] || []);
  }
  else if (action === 'start-plan') startWorkout([target.dataset.planId]);
  else if (action === 'pause-session') pauseSession();
  else if (action === 'complete-set') completeSet();
  else if (action === 'confirm-delete-plan') confirmDeletePlan(target.dataset.planId);
  else if (action === 'delete-plan') deletePlan(target.dataset.planId);
  else if (action === 'repeat-workout') startWorkout(target.dataset.planIds.split(',').filter(Boolean), { allowRepeat: true, rewardXp: false });
  else if (action === 'finish-celebration') { closeModal(); navigate('home'); showToast('Treino salvo. Até o próximo treino!'); }
  else if (action === 'set-theme') { applyTheme(target.dataset.theme); openAppearanceModal(); }
  else if (action === 'toggle-switch') { target.classList.toggle('on'); showToast(target.classList.contains('on') ? 'Lembretes ativados.' : 'Lembretes desativados.'); }
  else if (action === 'close-modal') closeModal();
  else if (action === 'logout') window.location.assign(new URL('../../auth/login.html', scriptSource).href);
  else openSimpleModal(action);
});

modalBackdrop.addEventListener('click', event => { if (event.target === modalBackdrop) closeModal(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
document.addEventListener('dblclick', event => event.preventDefault(), { passive: false });

async function loadExercises() {
  // A tela inicial sempre abre no dia local definido pelo dispositivo.
  state.selectedDay = todayKey();
  // Navegadores bloqueiam requisições fetch para arquivos abertos com file://.
  // Nesse modo, o catálogo de reserva evita erros no console e mantém a prévia funcional.
  if (window.location.protocol === 'file:') {
    renderAll();
    return;
  }
  try {
    const [exerciseResponse, groupResponse, levelsResponse] = await Promise.all([
      fetch(EXERCISE_CATALOG_URL, { cache: 'no-store', headers: { Accept: 'application/json' } }),
      fetch(MUSCLE_GROUPS_CATALOG_URL, { cache: 'no-store', headers: { Accept: 'application/json' } }),
      fetch(LEVELS_CATALOG_URL, { cache: 'no-store', headers: { Accept: 'application/json' } })
    ]);
    if (!exerciseResponse.ok || !groupResponse.ok || !levelsResponse.ok) throw new Error('Não foi possível carregar os catálogos');
    const [exercises, muscleGroups, levels] = await Promise.all([exerciseResponse.json(), groupResponse.json(), levelsResponse.json()]);
    const validExercises = Array.isArray(exercises) ? exercises.filter(isValidExercise) : [];
    const validGroups = Array.isArray(muscleGroups) ? muscleGroups.filter(isValidMuscleGroup) : [];
    const validLevels = Array.isArray(levels) ? levels.filter(isValidLevel).sort((a, b) => a.minXp - b.minXp) : [];
    if (!validExercises.length || !validGroups.length || !validLevels.length) throw new Error('Os catálogos não possuem dados válidos');
    state.exercises = [...validExercises, ...state.customExercises];
    state.muscleGroups = validGroups;
    state.levels = validLevels;
  } catch {
    // O catálogo de reserva mantém a prévia funcional quando o arquivo é aberto via file://.
    // Em um servidor HTTP/HTTPS, o catálogo em data/exercises.json é a fonte carregada pelo app.
  }
  renderAll();
}

syncStreak();
applyTheme(state.theme, false);
loadExercises();
