const toast = document.querySelector('.auth-toast');
let toastTimeout;

function showToast(message) {
  toast.querySelector('span').textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 2800);
}

document.querySelectorAll('[data-password-toggle]').forEach(button => {
  button.addEventListener('click', () => {
    const input = button.parentElement.querySelector('input');
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    button.setAttribute('aria-label', isHidden ? 'Ocultar senha' : 'Mostrar senha');
    button.innerHTML = `<i data-lucide="${isHidden ? 'eye-off' : 'eye'}"></i>`;
    window.lucide?.createIcons();
  });
});

document.querySelectorAll('[data-demo-form]').forEach(form => {
  form.addEventListener('submit', event => {
    event.preventDefault();
    showToast('Layout demonstrativo: nenhuma conta foi enviada ou criada.');
  });
});

document.querySelector('[data-action="forgot-password"]')?.addEventListener('click', () => {
  showToast('Recuperação de senha é apenas visual nesta demonstração.');
});

document.addEventListener('dblclick', event => event.preventDefault(), { passive: false });
window.lucide?.createIcons();
