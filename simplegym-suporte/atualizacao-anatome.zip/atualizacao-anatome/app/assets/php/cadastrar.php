<?php
require __DIR__ . '/funcoes.php';
require __DIR__ . '/termos.php';
$dados = receberDados();
if (($dados['termsAccepted'] ?? null) !== VERSAO_TERMOS) {
    responder(['message' => 'Leia e aceite o termo de responsabilidade para criar sua conta.'], 422);
}
$nome = trim((string) ($dados['name'] ?? ''));
$email = strtolower(trim((string) ($dados['email'] ?? '')));
$senha = (string) ($dados['password'] ?? '');
$modalidade = $dados['trainingPreference'] ?? null;
if (!in_array($modalidade, ['musculacao', 'calistenia', 'ambas'], true)) responder(['message' => 'Escolha musculação, calistenia ou ambas.'], 422);
if (strlen($nome) < 2 || strlen($nome) > 80 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
    responder(['message' => 'Informe seu nome e um email válido.'], 422);
}
if (strlen($senha) < 8 || strlen($senha) > 72) responder(['message' => 'A senha deve ter entre 8 e 72 caracteres.'], 422);
protegerTentativas($email);
$conecta = conectarBanco();
try {
    $conecta->beginTransaction();
    $inserir = $conecta->prepare('INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)');
    $inserir->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
    $id = (int) $conecta->lastInsertId();
    $inserir = $conecta->prepare('INSERT INTO perfis_usuario (usuario_id, preferencia_treino) VALUES (?, ?)');
    $inserir->execute([$id, $modalidade]);
    $texto = textoTermos();
    $inserir = $conecta->prepare('INSERT INTO aceites_termos (usuario_id, versao, texto, texto_sha256) VALUES (?, ?, ?, ?)');
    $inserir->execute([$id, VERSAO_TERMOS, $texto, hash('sha256', $texto)]);
    $conecta->commit();
} catch (PDOException $erro) {
    if ($conecta->inTransaction()) $conecta->rollBack();
    if (($erro->errorInfo[1] ?? 0) === 1062) responder(['message' => 'Este email já possui uma conta. Faça login.'], 409);
    throw $erro;
}
iniciarLogin($id);
responder(['message' => 'Conta criada.'], 201);
